"""Wait for the matched pipeline and publish its all-site comparison."""
from __future__ import annotations
import hashlib
import json
import logging
from pathlib import Path
import subprocess
import sys
import time


def main(plan_path: Path) -> None:
    """Validate immutable reporting code, then consume the final live census."""
    plan = json.loads(plan_path.read_text())
    for path, expected in plan["source_sha256"].items():
        if hashlib.sha256(Path(path).read_bytes()).hexdigest() != expected:
            raise ValueError("Frozen reporting source changed: " + path)
    status = Path(plan["pipeline_status"])
    while json.loads(status.read_text())["exit_status"] is None:
        logging.info("Waiting for six-case native/Amber census")
        time.sleep(30)
    summary = Path(plan["cohort_root"]) / "controller/summary.json"
    if not summary.is_file():
        raise RuntimeError("Pipeline ended before producing a complete case census")
    subprocess.run([sys.executable, "-B", plan["script"], "--cohort-root", plan["cohort_root"]], check=True)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    main(Path(sys.argv[1]))
