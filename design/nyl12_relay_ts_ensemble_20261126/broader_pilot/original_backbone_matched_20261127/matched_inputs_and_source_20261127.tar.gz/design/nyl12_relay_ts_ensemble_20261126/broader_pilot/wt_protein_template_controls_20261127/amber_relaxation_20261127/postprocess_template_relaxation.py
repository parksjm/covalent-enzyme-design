"""Recanonicalize explicit dry Amber snapshots and publish matched diagnostics."""

from __future__ import annotations

import argparse
import csv
import importlib.util
import json
import logging
from pathlib import Path
import shutil
from types import ModuleType
from typing import Any

import numpy as np

from nyl12_covalent.catalytic_alignment_geometry import fit_coordinates, state_metrics
from nyl12_covalent.control_inspection import pdb_atoms, publish_subset, sha256
from nyl12_covalent.control_pymol import write_views
from nyl12_covalent.design_pa6_mapping import export_canonical_heavy
from nyl12_covalent.relay_any_amide import evaluate_model, load_graph
from nyl12_covalent.relay_broad_graph import CONFIG

BASE = Path(__file__).resolve().parent
PILOT = BASE.parents[1]
ANALYZER = (
    PILOT
    / "dgx_wt_control_qualification_20261127"
    / "comparison_20261127/analyze_controls.py"
)
REFERENCE = (
    PILOT
    / "dgx_wt_control_qualification_20261127"
    / "inspection_export_20261127/crystal_reference.pdb"
)


def load_analyzer() -> ModuleType:
    """Load retained protein-only pairing implementation without running its CLI."""
    spec = importlib.util.spec_from_file_location("retained_control_analysis", ANALYZER)
    if spec is None or spec.loader is None:
        raise ImportError(ANALYZER)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def write_json(path: Path, data: Any) -> None:
    """Write authoritative finite JSON."""
    path.write_text(json.dumps(data, indent=2, allow_nan=False) + "\n")


def write_table(path: Path, rows: list[dict[str, Any]]) -> None:
    """Write a nonempty rectangular comparison table."""
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def derived_views(source: Path, output: Path, mapping: dict[str, str]) -> None:
    """Derive physical-pair mature-local and biological precursor PDB views.

    Args:
        source: Original canonical mature-local Amber export.
        output: Existing destination directory.
        mapping: Independently assigned actual alpha-to-beta chain map.
    """
    rename = dict(zip(mapping.values(), "EFGH", strict=True))
    local, biological = [], []
    for line in source.read_text().splitlines():
        if line.startswith(("ATOM  ", "HETATM")):
            chain = rename.get(line[21], line[21])
            number = int(line[22:26])
            line = line[:21] + chain + line[22:]
            local.append(line)
            if chain in "EFGH":
                number += 232
            biological.append(line[:22] + f"{number:4d}" + line[26:])
    for name, lines in (
        ("canonical_mature_local", local),
        ("canonical_precursor", biological),
    ):
        (output / (name + ".pdb")).write_text("\n".join(lines + ["END"]) + "\n")


def compare_rows(before: list[dict], after: list[dict]) -> list[dict]:
    """Compare all fixed site/ligand/amide identities even when assignments change."""
    identity = ("site", "ligand", "carbonyl_c", "carbonyl_o", "leaving_n")

    def index(rows: list[dict]) -> dict[tuple, dict]:
        return {tuple(r[k] for k in identity): r for r in rows}

    left, right = index(before), index(after)
    if len(left) != 48 or len(right) != 48 or left.keys() != right.keys():
        raise ValueError("Expected identical48 unique site/ligand/amide identities")
    metrics = ("d1", "d2", "d3", "a_bd", "herschlag_phi", "nterm_to_leaving_n")
    return [
        {
            **dict(zip(identity, key, strict=True)),
            **{f"before_{m}": left[key][m] for m in metrics},
            **{f"after_{m}": right[key][m] for m in metrics},
            **{f"delta_{m}": right[key][m] - left[key][m] for m in metrics},
            "before_tier": left[key]["tier"],
            "after_tier": right[key]["tier"],
        }
        for key in sorted(left)
    ]


def native_diagnostics(atoms: dict, mapping: dict, evidence: dict, refs: dict) -> dict:
    """Reuse retained held-out native Thr diagnostic for each actual physical pair."""
    result = {}
    for alpha, beta in mapping.items():
        ref = refs[evidence["pair_fit_matrix"][alpha + beta]["best_reference_chain"]]
        mobile = {
            (r if c == alpha else r + 232, a): (e, np.array(x))
            for (c, r, a), (e, x) in atoms.items()
            if c in (alpha, beta)
        }
        keys = [(r, a) for r in (113, 186, 272, 274) for a in ("N", "CA", "C", "O")]
        rotation, mc, rc, rmsd = fit_coordinates(
            np.array([mobile[k][1] for k in keys]), np.array([ref[k][1] for k in keys])
        )
        aligned = {k: (e, (x - mc) @ rotation + rc) for k, (e, x) in mobile.items()}
        result[alpha + beta] = {"fit_rmsd_A": rmsd, **state_metrics(ref, aligned)}
    return result


def process(args: argparse.Namespace) -> None:
    """Publish before/after canonical exports after native Amber jobs complete.

    Args:
        args: Explicit CLI topology, restart, conversion, output and case paths.
    """
    if args.output_dir.exists():
        raise FileExistsError(args.output_dir)
    stage = args.output_dir.with_name("." + args.output_dir.name + "_staging")
    stage.mkdir(parents=True, exist_ok=False)
    analyzer = load_analyzer()
    refs = analyzer.reference_atoms()
    graph_path = CONFIG / "whole_l4_source.mol2"
    graph = load_graph(graph_path)
    maps = {c: {name: name for name in graph.elements} for c in "IJKL"}
    reports, models, pairing_maps = {}, [], []
    for label, restart in (
        ("before", args.before_restart),
        ("after", args.after_restart),
    ):
        name = f"{args.case}_{label}"
        target = stage / name
        target.mkdir()
        native = target / "amber_export_mature_local.pdb"
        receipt = export_canonical_heavy(
            args.topology, restart, args.conversion, native
        )
        write_json(target / "amber_export_receipt.json", receipt)
        atoms = pdb_atoms(native)
        mapping, evidence = analyzer.pairing(atoms, refs)
        pairing_maps.append(mapping)
        write_json(target / "pairing_evidence.json", evidence)
        derived_views(native, target, mapping)
        report = evaluate_model(
            pdb_atoms(target / "canonical_mature_local.pdb"), maps, graph
        )
        if len(report["all_amide_site_rows"]) != 48 or len(report["assigned"]) != 4:
            raise ValueError("Expected48 all-amide records and4 assigned sites")
        report["nearest_d1_per_site"] = [
            min(
                (r for r in report["all_amide_site_rows"] if r["site"] == site),
                key=lambda r: r["d1"],
            )
            for site in ("AE", "BF", "CG", "DH")
        ]
        report["interpretation"] = (
            "Matched before/after Amber ES geometry proxies; not activity, barrier or sampling convergence. Native Thr is diagnostic only."
        )
        write_json(target / "geometry_any_amide.json", report)
        for key, filename in (
            ("all_amide_site_rows", "geometry_all_48.csv"),
            ("assigned", "geometry_assigned_4.csv"),
            ("nearest_d1_per_site", "geometry_nearest_d1_4.csv"),
        ):
            write_table(target / filename, report[key])
        write_json(
            target / "native_thr_diagnostics.json",
            native_diagnostics(atoms, mapping, evidence, refs),
        )
        reports[label] = report
        models.append(name)
    if pairing_maps[0] != pairing_maps[1]:
        raise ValueError(
            "Physical alpha/beta assignment changed; review before comparing"
        )
    rows = compare_rows(
        reports["before"]["all_amide_site_rows"],
        reports["after"]["all_amide_site_rows"],
    )
    write_json(stage / "before_after_all48.json", rows)
    write_table(stage / "before_after_all48.csv", rows)
    summary = {
        label: {
            k: report[k]
            for k in ("assigned", "nearest_d1_per_site", "assigned_tier_ab_count")
        }
        for label, report in reports.items()
    }
    write_json(stage / "before_after_site_summary.json", summary)
    write_table(
        stage / "before_after_site_summary.csv",
        [
            {"snapshot": label, "selection": key, **row}
            for label, report in reports.items()
            for key in ("assigned", "nearest_d1_per_site")
            for row in report[key]
        ],
    )
    shutil.copy2(REFERENCE, stage / "crystal_reference.pdb")
    fit = sorted(
        r
        for c, r, a in pdb_atoms(REFERENCE)
        if c == "A" and a == "CA" and 20 <= r <= 215 and r not in (113, 186)
    )
    write_views(stage, models, fit)
    inputs = [
        args.topology,
        args.before_restart,
        args.after_restart,
        args.conversion,
        ANALYZER,
        graph_path,
        REFERENCE,
        Path(__file__),
    ]
    write_json(
        stage / "input_source_hashes.json",
        {str(p.resolve()): sha256(p) for p in inputs},
    )
    (stage / "README.md").write_text(
        "# Matched WT template Amber inspection\n\n"
        "Open load_all_controls.pml from this portable directory in PyMOL. Scenes show before/after with one protein-core rigid fit.\n\n"
        "Canonical precursor views use alpha A-D1-232, beta E-H233-328 and ligands I-L; mature-local beta is1-96. Original engine-chain exports and independently measured physical-pair evidence are retained. Both snapshots are exported from explicit topology/restart inputs after Amber, before RFD3.\n\n"
        "All three internal amides × four ligands × four physical sites are retained per snapshot. JSON is authoritative; CSV is tabular. Assigned one-to-one and nearest-d1/site selections are separate; fixed-identity48-row deltas preserve changed best amides. Signed phi uses the same graph mapping; nterm_to_leaving_n measures Nalpha–leaving-N.\n\n"
        "Geometry and native-Thr diagnostics do not certify stationary-point force convergence, chemical retention, sampling convergence or activity. Engine process/scientific acceptance and proton inventories remain separate records in the parent job directory.\n"
    )
    publish_subset(stage, args.output_dir)
    logging.info("Published canonical before/after inspection: %s", args.output_dir)


def main() -> None:
    """Require explicit native Amber files; never infer or substitute a snapshot."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--case",
        required=True,
        choices=("af3_template_seed20261126", "boltz_template_seed20261126"),
    )
    for name in (
        "topology",
        "before-restart",
        "after-restart",
        "conversion",
        "output-dir",
    ):
        parser.add_argument("--" + name, type=Path, required=True)
    process(parser.parse_args())


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    main()
